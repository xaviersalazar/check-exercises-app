# check-exercises-app
An app used to check your missing codeup assignments, built with [Electron](https://electronjs.org/)

# how to use
* [Download here](https://github.com/xaviersalazar/check-exercises-app/releases/download/1.3.4/check-exercises-darwin-x64-1.3.4.zip), and unzip
* Run the check-exercises.app file
* After opening the app, you'll also need to goto your *System Preferences -> Security & Privacy* then under click the *Open Anyways* button to open the app. This happens because I  don't have a certificate, yet

# contributing
If you've never contributed to a project before, I would recommend going [here](https://github.com/Roshanjossey/first-contributions) first, as it will guide you through your first contribution and is very similar to the flow used here

Please follow the steps [here](CONTRIBUTING.md) to contribute